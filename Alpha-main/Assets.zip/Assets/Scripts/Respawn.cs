using System.Collections;
using System.Collections.Generic; // This line is necessary for 'List<>'
using UnityEngine;

public class MonsterSpawner : MonoBehaviour
{
    // Prefabs for different difficulty levels
    public GameObject easyMonsterPrefab;
    public GameObject mediumMonsterPrefab;
    public GameObject hardMonsterPrefab;
    public GameObject powerUpPrefab; // Assign your power-up prefab in the inspector

    // Configuration parameters
    public int initialMonstersToSpawn = 3;
    public float spawnInterval = 5f;
    private float screenMinX = -11f;
    private float screenMaxX = 14f;
    private float spawnY = 3f; // Y position just above the screen
    private int currentWave = 0;
    private float minSpawnDistance = 2f; // Minimum distance between spawned monsters

    // Keep track of spawned positions to avoid overlapping
    private List<Vector3> spawnedPositions = new List<Vector3>();

    // Enum to represent difficulty levels
    public enum Difficulty { Easy, Medium, Hard }
    public Difficulty gameDifficulty; // Set this in the inspector for each scene

    private void Start()
    {
        StartCoroutine(SpawnWave());
    }

    private IEnumerator SpawnWave()
    {
        currentWave++;
        spawnedPositions.Clear(); // Clear previous positions

        int monstersToSpawn = initialMonstersToSpawn;
        // For Hard difficulty, increment the number of monsters with each wave
        if (gameDifficulty == Difficulty.Hard)
        {
            monstersToSpawn += currentWave - 1;
        }

        for (int i = 0; i < monstersToSpawn; i++)
        {
            SpawnMonster();
            yield return new WaitForSeconds(0.1f); // Small delay between each spawn
        }

        // Drop a power-up every two waves, except for Hard mode which could be endless
        if (gameDifficulty != Difficulty.Hard && currentWave % 2 == 0)
        {
            DropPowerUp();
        }

        // Continue spawning waves for Hard mode or if we haven't reached the total waves for other difficulties
        if (gameDifficulty == Difficulty.Hard || currentWave < 5)
        {
            yield return new WaitForSeconds(spawnInterval);
            StartCoroutine(SpawnWave());
        }
        else
        {
            Debug.Log("Finished Spawning Monsters");
            // Game finish logic or transition to another scene could be added here
        }
    }

    private void SpawnMonster()
    {
        // Choose the prefab based on the selected difficulty
        GameObject prefabToSpawn = easyMonsterPrefab; // Default to Easy
        switch (gameDifficulty)
        {
            case Difficulty.Easy:
                prefabToSpawn = easyMonsterPrefab;
                break;
            case Difficulty.Medium:
                prefabToSpawn = mediumMonsterPrefab;
                break;
            case Difficulty.Hard:
                prefabToSpawn = hardMonsterPrefab;
                break;
        }

        // Instantiate the monster at a random position
        Vector3 spawnPosition = GetRandomSpawnPosition();
        Instantiate(prefabToSpawn, spawnPosition, Quaternion.identity);
    }

    private Vector3 GetRandomSpawnPosition()
    {
        Vector3 spawnPosition;
        bool positionValid = false;
        do
        {
            float randomX = Random.Range(screenMinX, screenMaxX);
            spawnPosition = new Vector3(randomX, spawnY, 0f);

            positionValid = true;
            foreach (Vector3 prevPosition in spawnedPositions)
            {
                if (Vector3.Distance(prevPosition, spawnPosition) < minSpawnDistance)
                {
                    positionValid = false;
                    break;
                }
            }
        } while (!positionValid);

        spawnedPositions.Add(spawnPosition);
        return spawnPosition;
    }

    private void DropPowerUp()
    {
        float randomX = Random.Range(screenMinX, screenMaxX);
        Vector3 dropPosition = new Vector3(randomX, spawnY, 0f);
        Instantiate(powerUpPrefab, dropPosition, Quaternion.identity);
    }
}
