Thanks for buying this,

There is a selection of image files in the "Textures" folder, you can add these to newly made materials or edit the demo ones I've added in the "Materials" folder.

There is a simple demo script to illustrate the ability to layer these materials to create depth. 

Please keep this asset library updated, if there are any changes or fixes or additions to make, I'd like you to have them.

support@dilapidatedmeow.com if you need help applying them, however I cannot help with scripting related issues, only problems with the assets. 